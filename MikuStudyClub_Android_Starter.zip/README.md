# Miku Study Club — Android prototype

A small Kotlin + Jetpack Compose starter project for a personal study app.

## Open in Android Studio
1. Install Android Studio.
2. Choose **Open** and select this folder.
3. Allow Gradle sync to finish.
4. Run on an Android emulator or connected phone.

## Current prototype
- Home screen and daily study plan
- Subjects screen
- Miku chat screen (UI demo only; no AI backend connected yet)
- Progress screen (placeholder)

## Next development steps
- Persist tasks and progress locally (Room or DataStore)
- Add lesson content and quizzes
- Connect an AI tutor through a secure backend; do not put a private API key in the Android app.
- Add an original or properly licensed Miku-inspired visual asset.
