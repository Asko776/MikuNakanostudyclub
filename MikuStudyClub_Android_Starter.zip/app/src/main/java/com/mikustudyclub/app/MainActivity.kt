package com.mikustudyclub.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF25345C)
private val Blue = Color(0xFF6E91D8)
private val Pale = Color(0xFFEAF0FF)
private val Ink = Color(0xFF26324B)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MikuApp() }
    }
}

@Composable
fun MikuApp() {
    var tab by remember { mutableStateOf(0) }
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Navy, secondary = Blue, background = Color(0xFFF7F8FC),
            surface = Color.White, onBackground = Ink, onSurface = Ink
        )
    ) {
        Scaffold(
            containerColor = Color(0xFFF7F8FC),
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    val items = listOf("Главная", "Предметы", "Мику", "Прогресс")
                    val icons = listOf(Icons.Default.Home, Icons.Default.MenuBook, Icons.Default.Chat, Icons.Default.Insights)
                    items.forEachIndexed { index, label ->
                        NavigationBarItem(
                            selected = tab == index,
                            onClick = { tab = index },
                            icon = { Icon(icons[index], contentDescription = label) },
                            label = { Text(label, fontSize = 10.sp) }
                        )
                    }
                }
            }
        ) { padding ->
            when (tab) {
                0 -> HomeScreen(Modifier.padding(padding), onChat = { tab = 2 })
                1 -> SubjectsScreen(Modifier.padding(padding))
                2 -> ChatScreen(Modifier.padding(padding))
                else -> ProgressScreen(Modifier.padding(padding))
            }
        }
    }
}

@Composable
fun Page(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 18.dp), content = content)
}

@Composable
fun HomeScreen(modifier: Modifier, onChat: () -> Unit) {
    Page(modifier) {
        Text("MIKU STUDY CLUB", color = Blue, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Spacer(Modifier.height(8.dp))
        Text("Привет! Давай учиться 💙", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Navy)
        Spacer(Modifier.height(16.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Pale), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.padding(18.dp)) {
                Text("Мику", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Navy)
                Spacer(Modifier.height(6.dp))
                Text("«Эм… Я подготовила для тебя небольшой план. Давай начнём не спеша?»", color = Ink, fontSize = 15.sp)
                Spacer(Modifier.height(12.dp))
                Button(onClick = onChat, colors = ButtonDefaults.buttonColors(containerColor = Navy)) {
                    Text("Поговорить с Мику")
                }
            }
        }
        Spacer(Modifier.height(20.dp))
        Text("Твой сегодняшний план", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Navy)
        Spacer(Modifier.height(10.dp))
        TaskRow("Японский язык", "10 минут · повторить хирагану", "あ")
        TaskRow("Английский", "10 минут · 5 новых слов", "A")
        TaskRow("Школьный предмет", "10 минут · разобрать одну тему", "✎")
        Spacer(Modifier.height(18.dp))
        Text("Маленькие шаги тоже считаются.", color = Color.Gray, fontSize = 13.sp)
    }
}

@Composable
fun TaskRow(title: String, subtitle: String, symbol: String) {
    Card(Modifier.fillMaxWidth().padding(vertical = 5.dp), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).background(Pale, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                Text(symbol, color = Navy, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold, color = Navy)
                Text(subtitle, fontSize = 12.sp, color = Color.Gray)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Blue)
        }
    }
}

@Composable
fun SubjectsScreen(modifier: Modifier) {
    Page(modifier) {
        Text("Предметы", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Navy)
        Text("Выбирай, что будем изучать сегодня.", color = Color.Gray)
        Spacer(Modifier.height(16.dp))
        TaskRow("Японский язык", "Хирагана · катакана · базовые фразы", "あ")
        TaskRow("Английский язык", "Грамматика · слова · speaking", "A")
        TaskRow("Школьные предметы", "Математика · история · география", "✎")
        TaskRow("Общие знания", "Узнавай, как устроен мир", "★")
    }
}

@Composable
fun ChatScreen(modifier: Modifier) {
    var message by remember { mutableStateOf("") }
    var sent by remember { mutableStateOf(false) }
    Page(modifier) {
        Text("Чат с Мику", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Navy)
        Text("Спокойно, без спешки. Можно спросить о чём угодно из учёбы.", color = Color.Gray)
        Spacer(Modifier.height(18.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Pale), shape = RoundedCornerShape(20.dp)) {
            Text("Мику: «Эм… Привет. Что сегодня будем разбирать? Я постараюсь объяснить всё понятно.»",
                Modifier.padding(16.dp), color = Navy)
        }
        if (sent) {
            Spacer(Modifier.height(10.dp))
            Card(shape = RoundedCornerShape(20.dp)) {
                Text("Ты: $message", Modifier.padding(16.dp))
            }
            Spacer(Modifier.height(10.dp))
            Text("Это пока макет чата. Подключение настоящего ИИ добавим следующим этапом.", color = Color.Gray, fontSize = 13.sp)
        }
        Spacer(Modifier.weight(1f))
        OutlinedTextField(
            value = message, onValueChange = { message = it }, modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Напиши сообщение…") }, shape = RoundedCornerShape(18.dp), maxLines = 3
        )
        Spacer(Modifier.height(8.dp))
        Button(onClick = { if (message.isNotBlank()) sent = true }, modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Navy)) {
            Text("Отправить")
        }
    }
}

@Composable
fun ProgressScreen(modifier: Modifier) {
    Page(modifier) {
        Text("Мой прогресс", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Navy)
        Spacer(Modifier.height(16.dp))
        Card(shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(18.dp)) {
                Text("Начало пути", color = Blue, fontWeight = FontWeight.Bold)
                Text("0 завершённых занятий", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Navy)
                Text("Когда начнёшь заниматься, здесь появится твоя статистика.", color = Color.Gray)
            }
        }
        Spacer(Modifier.height(14.dp))
        Text("Цель на день", fontWeight = FontWeight.Bold, color = Navy)
        LinearProgressIndicator(progress = { 0f }, modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp))
        Text("0 из 30 минут", color = Color.Gray, fontSize = 13.sp)
    }
}
